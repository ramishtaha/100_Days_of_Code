temp = []
towers = {
    'Source': [],
    'Destination': [],
    'Auxiliary': [],
}


def init_tower_a(n):
    # global tower_a, tower_b, tower_c
    global towers
    for i in range(1, n + 1):
        s = '█' * i * 2
        temp.append(s)
    towers['Source'] += temp[::-1]


def print_tower(tower, n):
    t = towers[tower][::-1]
    s = len(t)
    d = n - s
    # for i in t:
    #     print(i.center(20))
    for j in range(n):
        a = j - d
        if a >= 0:
            print(t[a].center(20))
        else:
            print('║'.center(20))

    print('════════════════════')
    print(tower.center(20))




def move(source, destination):
    global towers
    towers[destination].append(towers[source][-1])
    towers[source].pop(-1)
